import argparse
import numpy as np
import mujoco
import mujoco.viewer
import time
import os
from stable_baselines3 import PPO
from robotArmEnv import robotArmEnv, generateXML, ik_dls
import ompl.base as ob
import ompl.geometric as og


def main():
    parser = argparse.ArgumentParser(description="Visualize a robot from a PPO model.")
    parser.add_argument("model_path", type=str, help="Path to the PPO .zip model")
    args = parser.parse_args()

    model_path = args.model_path
    if not os.path.exists(model_path):
        print(f"Error: Model {model_path} not found.")
        return

    print(f"Loading model from {model_path}...")
    try:
        model_ppo = PPO.load(model_path)
    except Exception as e:
        print(f"Failed to load PPO model: {e}")
        return

    # Instantiate dummy env to get limits
    env = robotArmEnv()

    # Get action from model
    # We pass a dummy observation
    obs = np.array([0.0], dtype=np.float32)
    action, _ = model_ppo.predict(obs, deterministic=True)

    # Decode Action
    # Copied logic from robotArmEnv.step()
    numLinks = int(
        np.round(action[0] * (env.maxNumLinks - env.minNumLinks) + env.minNumLinks)
    )
    lengths = (
        action[1 : (env.maxNumLinks + 1)] * (env.maxLength - env.minLength)
        + env.minLength
    )[:numLinks]

    # Indices for joint types start after the max possible number of length params
    # action size = 1 + maxNumLinks + maxNumLinks = 1 + 2*maxNumLinks
    # 0: numLinks
    # 1..max: lengths
    # 1+max .. 1+2*max: jointTypes
    jointTypes = np.round(action[(1 + env.maxNumLinks) :] * 3)[:numLinks].astype(int)

    print(f"Decoded Robot: NumLinks={numLinks}")
    print(f"Lengths: {lengths}")
    print(f"JointTypes: {jointTypes}")

    # Generate XML
    xml = generateXML(numLinks, lengths, jointTypes)
    # print(xml)

    try:
        model = mujoco.MjModel.from_xml_string(xml)
        data = mujoco.MjData(model)
    except Exception as e:
        print(f"Error creating MuJoCo model: {e}")
        return

    # Setup OMPL (Replicating robotArmEnv logic)
    actuatorIds = [model.actuator(f"motor{i}").id for i in range(numLinks)]
    jointIds = [model.joint(f"joint{i}").id for i in range(numLinks)]
    obstacleNames = ["shelf", "shelfWall", "mountWall", "floor"]
    obstacleIds = set(
        [model.geom(name).id for name in obstacleNames if model.geom(name).id >= 0]
    )

    space = ob.CompoundStateSpace()
    isSO2 = []

    for link in range(numLinks):
        if jointTypes[link] == 2:
            space.addSubspace(ob.SO2StateSpace(), 1.0)
            isSO2.append(True)
        elif jointTypes[link] == 3:
            subspace = ob.RealVectorStateSpace(1)
            space.addSubspace(subspace, 1.0)
            bounds = ob.RealVectorBounds(1)
            bounds.setLow(0, 0)
            bounds.setHigh(0, lengths[link])
            subspace.setBounds(bounds)
            isSO2.append(False)
        else:
            subspace = ob.RealVectorStateSpace(1)
            space.addSubspace(subspace, 1.0)
            bounds = ob.RealVectorBounds(1)
            bounds.setLow(0, -np.pi / 2)
            bounds.setHigh(0, np.pi / 2)
            subspace.setBounds(bounds)
            isSO2.append(False)

    def isStateValid(state):
        qpos = np.zeros(numLinks)
        for i in range(numLinks):
            if isSO2[i]:
                qpos[i] = state[i].value
            else:
                qpos[i] = state[i][0]

        if not np.all(np.isfinite(qpos)):
            return False

        data.qpos[jointIds] = qpos
        mujoco.mj_forward(model, data)
        for j in range(data.ncon):
            contact = data.contact[j]
            if contact.geom1 in obstacleIds or contact.geom2 in obstacleIds:
                return False
        return True

    validityChecker = ob.StateValidityCheckerFn(isStateValid)
    si = ob.SpaceInformation(space)
    si.setStateValidityChecker(validityChecker)
    simpleSetup = og.SimpleSetup(si)

    # Visualization Loop
    # We will plan for all tasks defined in env and visualize sequentially
    startPoses = env.startPos
    goalPoses = env.goalPos

    pathStatesArr = []

    print("Planning for tasks...")
    for idx, (startPos, goalPos) in enumerate(zip(startPoses, goalPoses)):
        print(f"Task {idx}: Start={startPos}, Goal={goalPos}")

        startQpos, jStart = ik_dls(model, startPos)
        goalQpos, jGoal = ik_dls(model, goalPos, initialQpos=startQpos)

        if startQpos is None or goalQpos is None:
            print(f"  IK Failed for Task {idx}")
            pathStatesArr.append([])
            continue

        # Update sites for visualization
        # Note: the XML generator adds site names like 'startPos0', 'startPos1' if customized
        # But standard generateXML adds 'startPos' and 'goalPos'.
        # Since we are reusing env.generateXML which is generic, it might only have 'startPos' and 'goalPos'.
        # We will manually move them during the view loop.

        start = ob.State(space)
        goal = ob.State(space)

        # Populate OMPL states
        for i in range(len(startQpos)):
            # We assume startQpos matches jointIds order. ik_dls returns full qpos?
            # No, ik_dls returns q_best which is full qpos derived from model.nq
            # Since we generate model with ONLY robot joints + potentially baseBox (which has no joints),
            # the qpos SHOULD correspond to joints 0..N-1.
            # verification:
            # robotArmEnv generates joints named "joint{i}".
            # ik_dls uses model.nq.

            if isSO2[i]:
                start()[i].value = startQpos[i]
                goal()[i].value = goalQpos[i]
            else:
                start()[i][0] = startQpos[i]
                goal()[i][0] = goalQpos[i]

        simpleSetup.setStartAndGoalStates(start, goal)
        planner = og.RRTConnect(si)
        simpleSetup.setPlanner(planner)
        simpleSetup.solve(1.0)

        if simpleSetup.haveSolutionPath():
            print(f"  Path Found for Task {idx}")
            simpleSetup.simplifySolution()
            path = simpleSetup.getSolutionPath()
            path.interpolate(100)

            states = []
            for i in range(path.getStateCount()):
                # Deep copy step state
                stateCopy = space.allocState()
                space.copyState(stateCopy, path.getState(i))
                states.append(stateCopy)
            pathStatesArr.append(states)
        else:
            print(f"  No Path Found for Task {idx}")
            pathStatesArr.append([])

        planner.clear()
        simpleSetup.clear()

    # Launch Viewer
    print("Launching Viewer. Press Enter in the console to step through tasks...")
    with mujoco.viewer.launch_passive(model, data) as viewer:
        viewer.cam.lookat[:] = [0, 0, 1]
        viewer.cam.distance = 4.0
        viewer.cam.elevation = -30
        viewer.cam.azimuth = 135

        mujoco.mj_forward(model, data)
        viewer.sync()

        time.sleep(1)

        for idx, (pathStates, startPos, goalPos) in enumerate(
            zip(pathStatesArr, startPoses, goalPoses)
        ):
            print(f"Showing Task {idx}...")

            # Move visualization sites
            try:
                # The XML has 'startPos' and 'goalPos'.
                # If we want to visualize multiple, we reuse these sites.
                model.site("startPos").pos = startPos
                model.site("goalPos").pos = goalPos
            except:
                pass

            viewer.sync()

            if not pathStates:
                print(f"Skipping Task {idx} (No path)")
                time.sleep(1)
                continue

            # Animate
            i = 0
            while viewer.is_running() and i < len(pathStates):
                state = pathStates[i]
                qpos = np.zeros(numLinks)
                for j in range(numLinks):
                    if isSO2[j]:
                        qpos[j] = state[j].value
                    else:
                        qpos[j] = state[j][0]

                data.qpos[jointIds] = qpos
                mujoco.mj_forward(model, data)
                viewer.sync()
                time.sleep(0.02)
                i += 1

            time.sleep(0.5)

        print("Done. Viewer open. Ctrl+C to exit.")
        while viewer.is_running():
            viewer.sync()
            time.sleep(0.1)


if __name__ == "__main__":
    main()
