# sarsa_lambda_agent.py
import numpy as np

class SarsaLambdaAgent:
    """
    An agent that uses SARSA(λ) with accumulating eligibility traces.
    """
    def __init__(self, action_space_size, state_space_size, alpha=0.1, gamma=0.9, epsilon=0.1, lambda_val=0.9):
        self.q_table = np.zeros((state_space_size, action_space_size))
        # Eligibility trace table, initialized to zeros
        self.e_table = np.zeros((state_space_size, action_space_size))
        
        self.alpha = alpha
        self.gamma = gamma
        self.epsilon = epsilon
        self.lambda_val = lambda_val
        self.action_space_size = action_space_size
        
    def choose_action(self, state):
        """
        Action selection using epsilon-greedy policy.
        """
        # --- YOUR CODE HERE --- #

    def reset_traces(self):
        """
        Resets the eligibility traces to zero. Should be called at the start of each episode.
        """
        # --- YOUR CODE HERE --- #

    def update(self, state, action, reward, next_state, next_action):
        """
        Updates the Q-table and eligibility traces using the SARSA(λ) backward view.
        """
        # --- YOUR CODE HERE --- #
